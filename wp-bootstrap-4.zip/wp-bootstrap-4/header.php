<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WP_Bootstrap_4
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<?php wp_head(); ?>

	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style.css">
	<script type="text/javascript"  src="<?php echo get_template_directory_uri(); ?>/assets/js/front_page.js"></script>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">

	<header id="masthead" class="site-header fixed-top">
		<div class="container">
			<nav id="site-navigation" class="main-navigation navbar navbar-expand-lg">

				<div id="logo">
					<a href="#" class="image-logo">
						<img src="wp-content/themes/wp-bootstrap-4/assets/images/design_desk_logo_white_new.png" class="alt-logo" alt="">
					</a>
				</div>

				<div id="togglerBtn" class="toggler" onclick="showSidenav()">
			        <div class="top-line"></div>
			        <div class="mid-line"></div>
			        <div class="bot-line"></div>
      			</div> <!-- Toggler End-->


				<div class="collapse-lg navbar-collapse  ml-auto" id="navbarSupportedContent">
					<ul id="sidenav" class="nav navbar-nav navbar-right ">
						<li class="nav-item active">
							<a class="nav-link" href="#"> Portfolio </a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#"> Video Gallery </a>
						</li>
						<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          About 
					        </a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
					          <a class="dropdown-item" href="#">Overview</a>
					          <a class="dropdown-item" href="#">Capabilities</a>
					          <a class="dropdown-item" href="#">Team</a>
					          <a class="dropdown-item" href="#">What's New</a>

					        </div>
					    </li>					
						<li class="nav-item">
							<a class="nav-link" href="#"> Blog </a>
						</li>
						<li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					          Careers 
					        </a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
					          <a class="dropdown-item" href="#">Work at designdesk</a>
					          <a class="dropdown-item" href="#">life at designdesk</a>
					        </div>
					    </li>
						<li class="nav-item">
							<a class="nav-link" href="#"> Contact </a>
						</li>
					</ul>
					    

				</div>
			</nav> 
		</div>
	</header>

	

	<div id="content" class="site-content" >
