<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WP_Bootstrap_4
 */

get_header(); ?>

<?php
	$default_sidebar_position = get_theme_mod( 'default_sidebar_position', 'right' );
?>

<?php if ( get_theme_mod( 'blog_display_cover_section', 1 ) ) : ?>
	<?php if( get_theme_mod( 'blog_cover_title' ) || get_theme_mod( 'blog_cover_lead' ) || get_theme_mod( 'blog_cover_btn_text' ) ) : ?>
		<section class="jumbotron bg-white text-center wp-bs-4-jumbotron border-bottom">
			<div class="container">

				<h1 class="jumbotron-heading"><?php echo wp_kses_post( get_theme_mod( 'blog_cover_title' ) ); ?></h1>
				<p class="lead text-muted"><?php echo wp_kses_post( get_theme_mod( 'blog_cover_lead' ) ); ?></p>
				<?php if( get_theme_mod( 'blog_cover_btn_text' ) ) : ?><a href="<?php echo esc_url( get_theme_mod( 'blog_cover_btn_link' ) ); ?>" class="btn btn-primary"><?php echo esc_html( get_theme_mod( 'blog_cover_btn_text' ) ); ?></a><?php endif; ?>
			</div>
			<!-- /.container -->
		</section>
		<!-- /.jumbotron text-center -->
	<?php endif; ?>
<?php endif; ?>

<div id="carousel-example" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example" data-slide-to="1"></li>
    <li data-target="#carousel-example" data-slide-to="2"></li>
  </ol>

  <div class="carousel-inner">
    <div class="item active">
      <a href="#"><img src="wp-content/themes/wp-bootstrap-4/assets/images/firstbanner-1.jpg" ></a>
      <div class="carousel-caption">
        <h6>You Have Reached The Experts For</h6>
        <h2>Top Notch Exhibition Stands</h2>
      </div>
    </div>
   <!--  <div class="item">
      <a href="#"><img src="http://placekitten.com/1600/600" /></a>
      <div class="carousel-caption">
        <h3>Meow</h3>
        <p>Just Kitten Around</p>
      </div>
    </div>
    <div class="item">
      <a href="#"><img src="http://placekitten.com/1600/600" /></a>
      <div class="carousel-caption">
        <h3>Meow</h3>
        <p>Just Kitten Around</p>
      </div>
    </div> -->
  </div>

  <a class="left carousel-control" href="#carousel-example" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>




<!-- /.our approach -->
	<!-- <div class="our_approach">
		<div class="container">
			<h2 class="section_title">Our Approach</h2>
				<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-12 approach_block">
						<img src="wp-content/themes/wp-bootstrap-4/assets/images/approach_img1.png" alt="">
						<h2 class="listen-text">We Listen</h2>
							<p class="info_one"> Dedicated &</p>
							<p class="info_two">highly responsive</p>
							<p class="info_three"> Client Service</p>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 approach_block">
						<img src="wp-content/themes/wp-bootstrap-4/assets/images/approach_img2.png" alt="">
						<h2 class="design-text">We Design</h2>
							<p class="info_one"> A winning combination of</p>
							<p class="info_two">expertise & experience</p>
							<p class="info_three"> Design & Layout</p>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 approach_block">
						<img src="wp-content/themes/wp-bootstrap-4/assets/images/approach_img3.png" alt="">
						<h2 class="deliver-text">We Deliver</h2>
							<p class="info_one"> Reputed for best</p>
							<p class="info_two"> quality & service</p>
							<p class="info_three"> Project Execution</p>
					</div>
				</div>
		</div>
	</div> -->
	<!-- /.our approach -->

	<!-- /.our why-choose-us -->
	<div class="why_choose_us">
		<div class="left-side"></div>
			<div class="right-side">
			<div class="opacity">
			 <h2 class="choose_us_title"> 4 Reasons to choose us </h2>
				<div class="choose_reason item1">
					<h6 class="item_heading">1. Business focused Design</h6>
					<p class="item_text">We consider a Design successful only when it meets your marketing & brand objectives.<br>
						<a href="#">Read more</a>
					</p>
				</div>
				<div class="choose_reason item2">
					<h6 class="item_heading">2. Responsive Service</h6>
					<p class="item_text">Our dedicated service managers work closely with you to deliver the perfect exhibit. <br>
						<a href="#">Read more</a>
					</p>
				</div>
				<div class="choose_reason item3">
					<h6 class="item_heading">3. Immaculate Execution</h6>
					<p class="item_text">The quality of a booth is said to reflect the standard of the company & its products. <br>
						<a href="#">Read more</a><br>
					</p>
				</div>
				<div class="choose_reason item4">
					<h6 class="item_heading">4. 100% Reliable Partner</h6>
					<p class="item_text">When you don’t want to take chances with your exhibition stand, you need a capable & experienced partner.<br>
						<a href="#">Read more</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<!-- end -why-choose-us -->

<!-- counters -->
<!-- 	<div class="counter_in_home">
		<div class="row">
<div class="container">
		<div class="row text-center">
	        <div class="col">
	        <div class="counter">
      <i class="fa fa-code fa-2x"></i>
      <h2 class="timer count-title count-number" data-from="0" data-to="13" data-speed="1200"></h2>
       <p class="count-text ">Years in business</p>
    </div>
	        </div>
              <div class="col">
               <div class="counter">
      <i class="fa fa-coffee fa-2x"></i>
      <h2 class="timer count-title count-number" data-from="0" data-to="1200" data-speed="1200"></h2>
      <p class="count-text ">Projects delivered</p>
    </div>
              </div>
              <div class="col">
                  <div class="counter">
      <i class="fa fa-lightbulb-o fa-2x"></i>
      <h2 class="timer count-title count-number" data-from="0" data-to="45" data-speed="1200"></h2>
      <p class="count-text ">Member team</p>
    </div></div>
              <div class="col">
              <div class="counter">
      <i class="fa fa-bug fa-2x"></i>
      <h2 class="timer count-title count-number" data-from="0" data-to="26" data-speed="1200"></h2>
      <p class="count-text ">Countried covered</p>
    </div>
              </div>
         </div>
</div>
		</div>
	</div> -->

<!-- end of counter -->





	<!-- Brands -->
<!-- 	<div class="brands_logo">
		<div class="container">
			<h2 class="section_title"> Trusted By Brands Like </h2>
			    <div class="brand_items"> 
			   		<ul>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/swarovski.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/acg.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/reliance.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/aditya-birla-group.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/Mitsubishi_Electric.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/airbus.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/cisco.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/raychem-rpg.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/siyaram.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/uber.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/hitachi.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/gea.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/decor.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/portico.png" alt="">
				   			</a>
				   		</li>
				   		<li class="col-xs-4">
				   			<a href="#" class="brand" alt="">
				   				<img src="wp-content/themes/wp-bootstrap-4/assets/images/gmmco.png" alt="">
				   			</a>
				   		</li>
		        	</ul>
		        </div> 
		</div>
	</div>
		
 -->







<!-- 	<div class="members">
		<div class="container">
			<h2 class="section_title"> Members of</h2>
			<div class="left-logo d-inline">
			<a href="" class="text-center">
				<img src="wp-content/themes/wp-bootstrap-4/assets/images/ifes_logo.png" alt="">
			</a>
			</div>
			<div class="right-logo d-inline">
			<a href="" class="text-center">
				<img src="wp-content/themes/wp-bootstrap-4/assets/images/edpa_logo.png" alt="">
			</a>
			</div>
		</div>
	</div>
 -->




<?php
get_footer();
